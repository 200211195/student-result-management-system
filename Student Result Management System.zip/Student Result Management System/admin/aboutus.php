<html>
<head>
    <title>About</title>
<link rel="stylesheet" href="../csss/aboutus.css" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Flamenco" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

</head>
<body>
    <header>
      <nav>
        <div class="row clearfix">
            <ul class="main-nav" animate slideInDown>
                <li><a href="../index.php">HOME</a></li>
                <li><a href="aboutus.php">ABOUT</a></li>
                <li><a href="contactus.php">CONTACT</a></li>
                <li><a href="../login.php">ADMIN LOGIN</a></li>
          </ul>
        </div>
      </nav>
      <div class="main-content-header">
          <h2 class="search">About Us</h2>
             <div class="div2">
             <h3>Student Result Management System</h2>
             <p>This Software Application unbelievably unravels and quickens the result management system with unique templates by providing the administration a secure database system for storing, evaluating and publishing the test scores and grades of candidates online. The database likewise allows the student to observe and gander at the exam results on the web at whatever point necessary.</p>
             <p> Student Result Management System is a technological opportunity for the school, college university and coaching centre institutions searching for a secure, simple and alternative solution to the conventional paper-based exam results  evaluation, reporting and distribution.</p>
             </div>  
          </div>
    </header>
    
</body>
</html>